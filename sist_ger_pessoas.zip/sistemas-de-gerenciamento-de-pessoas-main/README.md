# 👀 Desenvolvendo um sistema de gerenciamento de pessoas em API REST com Spring Boot

## 🎮️ Sobre
O projeto é um API REST com Spring Boot para cadastro e gerenciamento de  pessoas de uma organização, até o deploy na nuvem (Heroku). que foi criado dentro do bootcamp everis FullStack Developer foi criado dentro do bootcamp Java Developer com o intuito de colocar em prática todo o conteúdo estudado durate o curso da DIO.

## 👨‍💻️ Tecnogias utilizadas
O projeto foi desenvolvido utilizando as seguintes tecnologias:

💻️Spring boot 💻️java 

## Feito com ❤️ por hellenm
